-- Apply with `python -m backend.setup_db`; the setup script adds missing columns idempotently.
CREATE TABLE IF NOT EXISTS database_connections (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(80) NOT NULL,
  encrypted_url MEDIUMTEXT NOT NULL,
  dialect VARCHAR(40) NOT NULL,
  is_default BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_dbconn_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_dbconn_user_default (user_id, is_default)
) ENGINE=InnoDB;
